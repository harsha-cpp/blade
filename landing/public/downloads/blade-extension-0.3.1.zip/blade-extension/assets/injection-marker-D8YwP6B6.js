const r="__bladeGmailGuardInstalled",n="__bladeWebGuardInstalled";function l(t,a=globalThis){const e=a;try{return e[t]===!0?!1:(e[t]=!0,!0)}catch{return!0}}export{r as G,n as W,l as c};
