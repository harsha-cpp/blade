const n="WEB_BLOCK";function o(t){const e=[...new Set(t.entities.map(s=>s.type))].sort().join(",");return`${t.site_host}|${e}`}export{n as W,o as w};
